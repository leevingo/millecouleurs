
****************************************************
User protect module -- README

written by Chad Phillips: thehunmonkgroup at gee mail com
****************************************************

This module provides various editing protection for users.

See INSTALL.txt for installation instructions.

See the module help at Administration » Help » User protect for a thorough
description of how to use the module.
